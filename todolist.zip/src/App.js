import React from 'react';
import './App.css';
import TodolistContainer from "./UI/TodolistContainer";

function App() {
    return (
        <div className="App">
            <TodolistContainer/>
        </div>
    );
}

export default App;
